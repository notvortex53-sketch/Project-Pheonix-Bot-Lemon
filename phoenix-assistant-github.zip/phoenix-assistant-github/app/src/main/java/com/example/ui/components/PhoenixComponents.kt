package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Note
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.SleekBg
import com.example.ui.theme.SleekBorder
import com.example.ui.theme.SleekGreen
import com.example.ui.theme.SleekOnPrimaryContainer
import com.example.ui.theme.SleekPrimary
import com.example.ui.theme.SleekPrimaryContainer
import com.example.ui.theme.SleekSurface
import com.example.ui.theme.SleekSurfaceVariant
import com.example.ui.theme.SleekTextMuted
import com.example.ui.theme.SleekTextPrimary
import com.example.ui.theme.SleekTextSecondary
import com.example.voice.VoiceState

@Composable
fun SafetyShieldBadge(
    label: String = "Zero-Exploit Verified",
    modifier: Modifier = Modifier
) {
    Surface(
        color = SleekGreen.copy(alpha = 0.12f),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SleekGreen.copy(alpha = 0.35f)),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = "Safe Shield",
                tint = SleekGreen,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = SleekGreen
            )
        }
    }
}

@Composable
fun OfflineVoicePrivacyBanner(
    isOffline: Boolean = true,
    wakeWordActive: Boolean = true,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = SleekSurface
        ),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SleekBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (wakeWordActive) SleekGreen else Color.Gray)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = if (wakeWordActive) "Hey Phoenix Wake-Word Active" else "Trigger: Standby",
                        color = SleekTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "100% On-Device Speech • Private Local Processing",
                        color = SleekTextSecondary,
                        fontSize = 10.sp
                    )
                }
            }

            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(SleekPrimaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Offline Privacy Lock",
                    tint = SleekPrimary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun VoicePulseOrb(
    voiceState: VoiceState,
    audioRms: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val isActive = voiceState == VoiceState.LISTENING_FOR_WAKE_WORD || voiceState == VoiceState.WAKE_WORD_ACTIVATED
    val effectiveScale = if (isActive) (pulseScale + audioRms * 0.35f).coerceIn(1f, 1.45f) else 1.0f

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(72.dp)
            .clickable(onClick = onClick)
            .testTag("voice_trigger_orb")
    ) {
        // Outer Sleek layered circle: bg-[#D6E3FF]/30
        if (isActive) {
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .scale(effectiveScale)
                    .clip(CircleShape)
                    .background(SleekPrimaryContainer.copy(alpha = 0.40f))
            )
            // Middle pulsing aura: bg-[#D6E3FF]/60
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .scale(effectiveScale * 0.9f)
                    .clip(CircleShape)
                    .background(SleekPrimaryContainer.copy(alpha = 0.70f))
            )
        }

        // Inner Core Orb: bg-[#005FB0]
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(if (isActive) SleekPrimary else SleekSurfaceVariant)
                .border(
                    1.5.dp,
                    if (isActive) SleekPrimaryContainer else SleekBorder,
                    CircleShape
                )
        ) {
            Icon(
                imageVector = if (isActive) Icons.Default.GraphicEq else Icons.Default.Mic,
                contentDescription = "Microphone Trigger",
                tint = if (isActive) Color.White else SleekTextSecondary,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
fun ActionCardView(
    actionType: String,
    title: String,
    details: String,
    status: String,
    onExecuteAgain: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val icon = when (actionType) {
        "OPEN_SPOTIFY" -> Icons.Default.MusicNote
        "SEARCH_GOOGLE" -> Icons.Default.Search
        "WRITE_NOTE" -> Icons.AutoMirrored.Filled.Note
        "RUN_CODE" -> Icons.Default.Code
        else -> Icons.Default.Security
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = SleekSurface),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SleekBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            // Sleek left accent indicator: border-l-4 border-[#005FB0]
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(96.dp)
                    .background(SleekPrimary)
            )

            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(SleekPrimaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = actionType,
                                tint = SleekPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = title,
                                color = SleekTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = actionType,
                                color = SleekPrimary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    SafetyShieldBadge()
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = details,
                    color = SleekTextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )

                if (onExecuteAgain != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Surface(
                            color = SleekPrimaryContainer,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.clickable { onExecuteAgain() }
                        ) {
                            Text(
                                text = "Re-Run Action",
                                color = SleekOnPrimaryContainer,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
