package com.example.network

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class LlamaChatRequest(
    @Json(name = "model") val model: String,
    @Json(name = "messages") val messages: List<LlamaMessage>,
    @Json(name = "temperature") val temperature: Double = 0.7,
    @Json(name = "max_tokens") val maxTokens: Int = 2048
)

@JsonClass(generateAdapter = true)
data class LlamaMessage(
    @Json(name = "role") val role: String,
    @Json(name = "content") val content: String
)

@JsonClass(generateAdapter = true)
data class LlamaChatResponse(
    @Json(name = "id") val id: String?,
    @Json(name = "choices") val choices: List<LlamaChoice>?,
    @Json(name = "model") val model: String?,
    @Json(name = "usage") val usage: LlamaUsage?
)

@JsonClass(generateAdapter = true)
data class LlamaChoice(
    @Json(name = "index") val index: Int?,
    @Json(name = "message") val message: LlamaMessage?,
    @Json(name = "finish_reason") val finishReason: String?
)

@JsonClass(generateAdapter = true)
data class LlamaUsage(
    @Json(name = "prompt_tokens") val promptTokens: Int?,
    @Json(name = "completion_tokens") val completionTokens: Int?,
    @Json(name = "total_tokens") val totalTokens: Int?
)
