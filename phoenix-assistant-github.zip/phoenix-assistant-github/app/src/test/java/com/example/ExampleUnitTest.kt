package com.example

import com.example.device.SafeAction
import com.example.sandbox.CodeSandboxEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    private val sandbox = CodeSandboxEngine()

    @Test
    fun `parse spotify voice command with stay by justin bieber`() {
        val input = "Hey Phoenix, open spotify and play stay by justin bieber"
        val action = SafeAction.parseFromText(input)
        assertNotNull(action)
        assertTrue(action is SafeAction.OpenSpotify)
        val spotifyAction = action as SafeAction.OpenSpotify
        assertEquals("stay by justin bieber", spotifyAction.query.lowercase())
    }

    @Test
    fun `parse notepad write voice command`() {
        val input = "open notepad and write buy eggs and milk"
        val action = SafeAction.parseFromText(input)
        assertNotNull(action)
        assertTrue(action is SafeAction.OpenNotepadAndWrite)
        val noteAction = action as SafeAction.OpenNotepadAndWrite
        assertEquals("buy eggs and milk", noteAction.content)
    }

    @Test
    fun `parse google search voice command`() {
        val input = "search on google for quantum computing"
        val action = SafeAction.parseFromText(input)
        assertNotNull(action)
        assertTrue(action is SafeAction.SearchGoogle)
        val searchAction = action as SafeAction.SearchGoogle
        assertEquals("quantum computing", searchAction.query)
    }

    @Test
    fun `sandbox executes mathematical calculations safely`() {
        val code = "val x = 12\nval y = 5\nsqrt(pow(x, 2) + pow(y, 2))"
        val result = sandbox.execute(code)
        assertTrue(result.isSuccess)
        assertEquals("13", result.returnValue)
    }

    @Test
    fun `sandbox executes sorting and lists safely`() {
        val code = "listOf(42, 11, 88, 3, 99).sorted()"
        val result = sandbox.execute(code)
        assertTrue(result.isSuccess)
        assertEquals("[3.0, 11.0, 42.0, 88.0, 99.0]", result.returnValue)
    }

    @Test
    fun `sandbox blocks exploit attempts with forbidden keywords`() {
        val dangerousCode = "Runtime.getRuntime().exec(\"rm -rf /\")"
        val result = sandbox.execute(dangerousCode)
        assertFalse(result.isSuccess)
        assertEquals("SECURITY_VIOLATION", result.returnValue)
        assertTrue(result.securityBadge.contains("BLOCKED"))
    }
}
