package com.example

import android.app.Application
import android.content.Intent
import com.example.data.local.ChatMessageEntity
import com.example.data.local.PhoenixDatabase
import com.example.data.local.TaskExecutionEntity
import com.example.data.repository.PhoenixRepository
import com.example.data.repository.SettingsRepository
import com.example.device.SafeAction
import com.example.device.SafeActionExecutor
import com.example.network.LlamaApiClient
import com.example.sandbox.CodeSandboxEngine
import com.example.voice.PhoenixSpeaker
import com.example.voice.VoiceRecognitionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class PhoenixApplication : Application() {

    lateinit var database: PhoenixDatabase
        private set

    lateinit var repository: PhoenixRepository
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var safeActionExecutor: SafeActionExecutor
        private set

    lateinit var codeSandboxEngine: CodeSandboxEngine
        private set

    lateinit var llamaApiClient: LlamaApiClient
        private set

    lateinit var speaker: PhoenixSpeaker
        private set

    lateinit var voiceManager: VoiceRecognitionManager
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()

        database = PhoenixDatabase.getDatabase(this)
        repository = PhoenixRepository(
            chatDao = database.chatDao(),
            taskDao = database.taskDao(),
            noteDao = database.noteDao()
        )
        settingsRepository = SettingsRepository(this)
        safeActionExecutor = SafeActionExecutor(this, repository)
        codeSandboxEngine = CodeSandboxEngine()
        llamaApiClient = LlamaApiClient()
        speaker = PhoenixSpeaker(this)

        // Single shared VoiceRecognitionManager
        voiceManager = VoiceRecognitionManager(this) { command, isHotword ->
            appScope.launch {
                handleBackgroundVoiceCommand(command, isHotword)
            }
        }

        // Pause recognizer while speaker is actively speaking to prevent echo loops
        speaker.onSpeakingStateChanged = { isSpeaking ->
            if (isSpeaking) {
                voiceManager.pauseForSpeaking()
            } else {
                voiceManager.resumeAfterSpeaking()
            }
        }

        // Pre-populate welcome message if history is empty
        appScope.launch(Dispatchers.IO) {
            val initial = ChatMessageEntity(
                role = "assistant",
                content = "Hey! I am Phoenix, your offline-first AI assistant.\n\n" +
                        "• Wake Word: Say \"Hey Phoenix\" anytime\n" +
                        "• Voice Privacy: 100% On-device speech recognition\n" +
                        "• Device Tasks: \"Hey Phoenix, open spotify and play stay by justin bieber\", \"open notepad and write buy milk\", \"search on google for quantum computing\", \"open camera\", \"open youtube\", \"open settings\"\n" +
                        "• Code Execution: Run safe sandboxed code snippets in Kotlin/Math\n" +
                        "• Online Chat: Powered by Groq GPT-OSS-120B / Llama model API key.",
                timestamp = System.currentTimeMillis()
            )
            repository.insertMessage(initial)
        }
    }

    suspend fun handleBackgroundVoiceCommand(command: String, isHotword: Boolean) {
        val triggerSource = if (isHotword) "VOICE_HOTWORD" else "VOICE_BUTTON"
        val currentSettings = settingsRepository.settings.value

        // 1. Record user voice input in chat
        repository.insertMessage(
            ChatMessageEntity(
                role = "user",
                content = if (isHotword) {
                    if (command == "TRIGGER_ASSISTANT") "Hey Phoenix" else "Hey Phoenix, $command"
                } else command,
                timestamp = System.currentTimeMillis(),
                isVoiceTriggered = true
            )
        )

        // 2. Try parsing direct safe device action
        val safeAction = SafeAction.parseFromText(command)
        if (safeAction != null) {
            // Provide immediate spoken feedback if enabled
            if (currentSettings.voiceFeedbackEnabled) {
                val spokenAnnouncement = when (safeAction) {
                    is SafeAction.OpenApp -> "Opening ${safeAction.appName}"
                    is SafeAction.OpenSpotify -> if (safeAction.query == "Top Hits") "Opening Spotify" else "Opening Spotify to play ${safeAction.query}"
                    is SafeAction.SearchGoogle -> "Searching Google for ${safeAction.query}"
                    is SafeAction.OpenNotepadAndWrite -> "Saving note to your notepad"
                    is SafeAction.SetTimer -> "Setting timer for ${safeAction.minutes} minutes"
                    is SafeAction.OpenSettings -> "Opening ${safeAction.settingType} settings"
                    is SafeAction.OpenAssistant -> "Phoenix is listening. How can I help you?"
                    is SafeAction.RunCode -> "Executing code snippet"
                }
                speaker.speak(spokenAnnouncement)
            }

            // Execute the action safely
            val result = safeActionExecutor.execute(safeAction, triggerSource)
            repository.insertTask(
                TaskExecutionEntity(
                    actionType = result.actionType,
                    title = result.title,
                    details = result.details,
                    timestamp = System.currentTimeMillis(),
                    status = if (result.success) "SUCCESS" else "FAILED",
                    triggerSource = triggerSource,
                    securityAudit = result.securityAudit
                )
            )

            // Reply in chat
            repository.insertMessage(
                ChatMessageEntity(
                    role = "assistant",
                    content = "${result.title}\n${result.details}",
                    timestamp = System.currentTimeMillis() + 100,
                    isVoiceTriggered = false,
                    actionType = result.actionType,
                    actionPayload = command,
                    actionStatus = if (result.success) "SUCCESS" else "FAILED"
                )
            )
        } else {
            // 3. Complex conversation / query -> Forward to Llama model if API key exists
            if (currentSettings.apiKey.isNotBlank()) {
                if (currentSettings.voiceFeedbackEnabled) {
                    speaker.speak("Looking that up for you")
                }

                val systemPrompt = "You are Phoenix, an intelligent device assistant. Your wake word is 'Hey Phoenix'. " +
                        "When the user requests device actions, use: " +
                        "[ACTION:OPEN_SPOTIFY query=\"...\"] or [ACTION:WRITE_NOTE title=\"...\" content=\"...\"] or " +
                        "[ACTION:SEARCH_GOOGLE query=\"...\"] or [ACTION:OPEN_APP app=\"...\"] or [ACTION:RUN_CODE lang=\"kotlin\"]...[/ACTION]. " +
                        "Keep answers helpful, concise, and structured."

                val response = llamaApiClient.chat(
                    baseUrl = currentSettings.apiBaseUrl,
                    apiKey = currentSettings.apiKey,
                    model = currentSettings.modelName,
                    systemPrompt = systemPrompt,
                    history = emptyList(),
                    userMessage = command
                )

                response.onSuccess { reply ->
                    repository.insertMessage(
                        ChatMessageEntity(
                            role = "assistant",
                            content = reply,
                            timestamp = System.currentTimeMillis() + 100
                        )
                    )
                    if (currentSettings.voiceFeedbackEnabled) {
                        val speechSummary = reply
                            .replace(Regex("""\[ACTION:.*?\]"""), "")
                            .replace(Regex("""\[/ACTION\]"""), "")
                            .take(200)
                        speaker.speak(speechSummary)
                    }
                }.onFailure { err ->
                    val errorMsg = "Could not reach assistant service (${err.message}). Check your API Key in Settings."
                    repository.insertMessage(
                        ChatMessageEntity(
                            role = "assistant",
                            content = errorMsg,
                            timestamp = System.currentTimeMillis() + 100
                        )
                    )
                    if (currentSettings.voiceFeedbackEnabled) {
                        speaker.speak("Could not reach the assistant service. Please check your API key in Settings.")
                    }
                }
            } else {
                val noKeyMsg = "I heard: \"$command\". To enable conversational AI, please enter your Groq API Key in Settings. You can still ask me to open any app, play Spotify, take notes, or search Google!"
                repository.insertMessage(
                    ChatMessageEntity(
                        role = "assistant",
                        content = noKeyMsg,
                        timestamp = System.currentTimeMillis() + 100
                    )
                )
                if (currentSettings.voiceFeedbackEnabled) {
                    speaker.speak("Please add your Groq API key in Settings to enable conversational questions. You can still ask me to open any app, play Spotify, or search Google.")
                }
            }
        }
    }
}
