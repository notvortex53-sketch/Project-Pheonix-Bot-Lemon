package com.example.data.repository

import com.example.data.local.ChatDao
import com.example.data.local.ChatMessageEntity
import com.example.data.local.NoteDao
import com.example.data.local.NoteEntity
import com.example.data.local.TaskDao
import com.example.data.local.TaskExecutionEntity
import kotlinx.coroutines.flow.Flow

class PhoenixRepository(
    private val chatDao: ChatDao,
    private val taskDao: TaskDao,
    private val noteDao: NoteDao
) {
    val allMessages: Flow<List<ChatMessageEntity>> = chatDao.getAllMessages()
    val allTasks: Flow<List<TaskExecutionEntity>> = taskDao.getAllTasks()
    val recentTasks: Flow<List<TaskExecutionEntity>> = taskDao.getRecentTasks(10)
    val allNotes: Flow<List<NoteEntity>> = noteDao.getAllNotes()

    suspend fun insertMessage(message: ChatMessageEntity): Long = chatDao.insertMessage(message)

    suspend fun updateMessage(message: ChatMessageEntity) = chatDao.updateMessage(message)

    suspend fun clearChat() = chatDao.clearHistory()

    suspend fun insertTask(task: TaskExecutionEntity): Long = taskDao.insertTask(task)

    suspend fun clearTasks() = taskDao.clearTasks()

    suspend fun insertNote(note: NoteEntity): Long = noteDao.insertNote(note)

    suspend fun updateNote(note: NoteEntity) = noteDao.updateNote(note)

    suspend fun deleteNote(id: Long) = noteDao.deleteNoteById(id)

    suspend fun clearNotes() = noteDao.clearNotes()
}
