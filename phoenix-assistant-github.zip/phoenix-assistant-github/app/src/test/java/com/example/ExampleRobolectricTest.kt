package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.device.SafeAction
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Phoenix Assistant", appName)
    }

    @Test
    fun `test wake word and app opening parsing`() {
        // Wake word alone triggers assistant
        val trigger = SafeAction.parseFromText("TRIGGER_ASSISTANT")
        assertTrue(trigger is SafeAction.OpenAssistant)

        val wakeUp = SafeAction.parseFromText("hey phoenix")
        assertTrue(wakeUp is SafeAction.OpenAssistant)

        // Opening camera
        val cameraAction = SafeAction.parseFromText("open camera")
        assertTrue(cameraAction is SafeAction.OpenApp)
        assertEquals("camera", (cameraAction as SafeAction.OpenApp).appName)

        // Opening youtube
        val youtubeAction = SafeAction.parseFromText("open youtube")
        assertTrue(youtubeAction is SafeAction.OpenApp)
        assertEquals("youtube", (youtubeAction as SafeAction.OpenApp).appName)

        // Opening spotify
        val spotifyAction = SafeAction.parseFromText("open spotify and play stay by justin bieber")
        assertTrue(spotifyAction is SafeAction.OpenSpotify)
        assertEquals("stay by justin bieber", (spotifyAction as SafeAction.OpenSpotify).query)

        // Opening settings
        val settingsAction = SafeAction.parseFromText("open settings")
        assertTrue(settingsAction is SafeAction.OpenSettings)
    }
}
